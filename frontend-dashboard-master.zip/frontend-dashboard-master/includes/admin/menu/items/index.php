<?php
/**
 * Silence is Good.
 *
 * @package Frontend Dashboard
 */
