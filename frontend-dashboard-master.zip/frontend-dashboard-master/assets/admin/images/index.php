<?php
/**
 * Silence is Good.
 *
 * @package frontend-dashboard.
 */

